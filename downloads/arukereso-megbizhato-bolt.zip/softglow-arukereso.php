<?php
/**
 * Plugin Name:       SoftGlow - Árukereső Megbízható Bolt Integráció
 * Description:       Hivatalos Árukereső SDK alapú, modern és szuperkönnyű Megbízható Bolt integráció WooCommerce-hez.
 * Version:           1.2.0
 * Author:            SoftGlow
 * License:           GPL-2.0+
 * Text Domain:       softglow-arukereso-megbizhato-bolt
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * 1. Adminisztrációs beállítások oldal létrehozása
 */
add_action( 'admin_menu', 'softglow_arukereso_admin_menu' );
function softglow_arukereso_admin_menu() {
    add_options_page(
        'Árukereső Megbízható Bolt',
        'Árukereső Megbízható Bolt',
        'manage_options',
        'softglow-arukereso-megbizhato-bolt',
        'softglow_arukereso_settings_page'
    );
}

function softglow_arukereso_settings_page() {
    if ( ! current_user_can( 'manage_options' ) ) {
        return;
    }

    if ( isset( $_POST['softglow_arukereso_nonce'] ) && wp_verify_nonce( $_POST['softglow_arukereso_nonce'], 'softglow_save_arukereso_settings' ) ) {
        $api_key = sanitize_text_field( $_POST['softglow_arukereso_api_key'] );
        update_option( 'softglow_arukereso_api_key', $api_key );
        echo '<div class="updated"><p>Beállítások sikeresen elmentve!</p></div>';
    }

    $current_key = get_option( 'softglow_arukereso_api_key', '' );
    ?>
    <div class="wrap">
        <h1>Árukereső Megbízható Bolt Integráció</h1>
        <form method="post" action="">
            <?php wp_nonce_field( 'softglow_save_arukereso_settings', 'softglow_arukereso_nonce' ); ?>
            <table class="form-table">
                <tr valign="top">
                    <th scope="row">Árukereső WebAPI Kulcs:</th>
                    <td>
                        <input type="text" name="softglow_arukereso_api_key" value="<?php echo esc_attr( $current_key ); ?>" class="regular-text" placeholder="Pl. a1b2c3d4e5f6..." />
                        <p class="description">Az Árukereső admin felületén található egyedi API kulcsod.</p>
                    </td>
                </tr>
            </table>
            <?php submit_button( 'Beállítások mentése' ); ?>
        </form>
    </div>
    <?php
}

/**
 * 2. Token lekérése és a JavaScript injektálása a köszönőoldalon (Hivatalos SDK logika alapján)
 */
add_action( 'woocommerce_thankyou', 'softglow_arukereso_trusted_shop_trigger' );
add_action( 'wfwaf_thankyou', 'softglow_arukereso_trusted_shop_trigger' );
function softglow_arukereso_trusted_shop_trigger( $order_id ) {
    if ( ! $order_id ) {
        return;
    }

    $api_key = get_option( 'softglow_arukereso_api_key', '' );
    if ( empty( $api_key ) ) {
        return;
    }

    $order = wc_get_order( $order_id );
    if ( ! $order ) {
        return;
    }

    $customer_email = $order->get_billing_email();
    if ( empty( $customer_email ) || $customer_email === 'somebody@example.com' ) {
        return;
    }

    // Termékek összegyűjtése névvel és azonosítóval (SKU vagy ID), pont ahogy az SDK kéri
    $products_array = array();
    foreach ( $order->get_items() as $item ) {
        $product = $item->get_product();
        if ( $product ) {
            // Megnézzük van-e cikkszám (SKU), ha nincs, a belső ID-t használjuk az XML feeddel való egyezéshez
            $product_id = $product->get_sku() ? $product->get_sku() : $product->get_id();
            
            $products_array[] = array(
                'Name' => $item->get_name(),
                'Id'   => $product_id
            );
        }
    }

    // TokenRequest paraméterek összeállítása (TrustedShop::VERSION = '2.0/PHP')
    $api_url = 'https://www.arukereso.hu/t2/TokenRequest.php';
    $params = array(
        'Version'   => '2.0/PHP',
        'WebApiKey' => $api_key,
        'Email'     => $customer_email,
        'Products'  => json_encode( $products_array )
    );

    // WordPress beépített HTTP kliens (gyors, biztonságos, 3 mp timeout-al, nem akasztja meg az oldalt)
    $response = wp_remote_post( $api_url, array(
        'method'    => 'POST',
        'timeout'   => 3,
        'body'      => http_build_query( $params ),
        'sslverify' => true
    ) );

    if ( is_wp_error( $response ) ) {
        return;
    }

    $status_code = wp_remote_retrieve_response_code( $response );
    $body        = wp_remote_retrieve_body( $response );
    $json_data   = json_decode( $body, true );

    // Ha az Árukereső szervere 200-as okéval visszadta a tokent
    if ( $status_code === 200 && ! empty( $json_data['Token'] ) ) {
        $token = sanitize_text_field( $json_data['Token'] );
        
        $query_args = array(
            'Token'     => $token,
            'WebApiKey' => $api_key,
            'C'         => ''
        );
        $query_string = '?' . http_build_query( $query_args );
        $fallback_random = md5( $api_key . microtime() );

        // Az Árukereső hivatalos kliensoldali kódjának kiköpése (aku.min.js betöltése)
        ?>
        <script type="text/javascript">
            window.aku_request_done = function(w, c) {
                var I = new Image(); 
                I.src = "https://www.arukereso.hu/t2/TrustedShop.php<?php echo $query_string; ?>" + c;
            };
            (function() {
                var a = document.createElement("script"); 
                a.type = "text/javascript"; 
                a.src = "https://assets.arukereso.com/aku.min.js"; 
                a.async = true;
                (document.getElementsByTagName("head")[0] || document.getElementsByTagName("body")[0]).appendChild(a);
            })();
        </script>
        <noscript>
            <img src="https://www.arukereso.hu/t2/TrustedShop.php<?php echo $query_string; ?><?php echo $fallback_random; ?>" style="display:none;" />
        </noscript>
        <?php
    }
}